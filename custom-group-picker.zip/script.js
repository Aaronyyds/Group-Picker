const csvPath = "data.csv";

let groupMap = {};

document.addEventListener("DOMContentLoaded", async () => {
  const response = await fetch(csvPath);
  const csvText = await response.text();
  const lines = csvText.trim().split("\n");
  const rows = lines.slice(1).map(line => {
    const [group, value] = line.split(",");
    return { group: group.trim(), value: value.trim() };
  });

  groupMap = rows.reduce((acc, { group, value }) => {
    if (!acc[group]) acc[group] = [];
    acc[group].push(value);
    return acc;
  }, {});

  renderControls(groupMap);
});

function renderControls(groups) {
  const controlDiv = document.getElementById("controls");
  controlDiv.innerHTML = "";

  for (const group in groups) {
    const div = document.createElement("div");
    div.className = "group-control";
    div.innerHTML = `
      <label>${group} count: 
        <input type="number" id="count-${group}" min="0" max="${groups[group].length}" value="2" />
      </label>
    `;
    controlDiv.appendChild(div);
  }

  document.getElementById("generate").addEventListener("click", () => generate(groups));
}

function generate(groups) {
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  for (const group in groups) {
    const count = parseInt(document.getElementById(`count-${group}`).value);
    const shuffled = [...groups[group]].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, count);

    const section = document.createElement("div");
    section.innerHTML = `<h3>${group}</h3><ul>${selected.map(item => `<li>${item}</li>`).join("")}</ul>`;
    resultsDiv.appendChild(section);
  }
}
